const form = document.getElementById("form");
form.addEventListener("submit", (e) => {
    e.preventDefault();

const mail = document.getElementById("email").value;
const passW = document.getElementById("password").value;


if (mail === "") {
    divmail.innerText = "*Email is required";
}
else {
    const result = isValidEmail(mail);
        if (result === true) {
            divmail.innerText = "";
        }
        else{
            divmail.innerText = "Invalid E-mail";
        } 
}

if (passW === "") {
    divpassword.innerText = "*Please enter your Password";
}
else {
    console.log(passW)
    const result = validatePassword(passW);
    console.log(result)
    if (result === true) {
        divpassword.innerText = "";
    }
    else {
        divpassword.innerText = "*Password must have more than 8 characters with atleast 1 Uppercase, 1 Lowercase, a Number and a Special character.";
    }
}


});

const isValidEmail = (mail) => {
    const re =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(mail).toLowerCase());
};

function validatePassword(passW) {

    return /[A-Z]/       .test(passW) &&
           /[a-z]/       .test(passW) &&
           /[0-9]/       .test(passW) &&
           /[^A-Za-z0-9]/.test(passW) &&
           passW.length > 8;

}