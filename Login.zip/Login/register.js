const form = document.getElementById("form");
form.addEventListener("submit", (e) => {
    e.preventDefault();

    const fname = document.getElementById("name1").value;
    const lname = document.getElementById("nameL").value;
    const mail = document.getElementById("email").value;
    const username = document.getElementById("Uname").value;
    const phone = document.getElementById("phn").value;
    const birth = document.getElementById("dob").value;
    const CR = document.getElementById("cr").value;
    const pW1 = document.getElementById("password1").value;
    const pW2 = document.getElementById("password2").value;
    const Cbox = document.getElementById("check2");


    if (fname === "") {
        divname1.innerText = "*FirstName is Required";
    }
    else {
        divname1.innerText = "";
    }


    if (lname === "") {
        divnameL.innerText = "*LastName is Required";
    }
    else {
        divnameL.innerText = "";
    }


    if (mail === "") {
        divemail.innerText = "*Email is Required";
    }
    else {
        const result = isValidEmail(mail);
        if (result === true) {
            divemail.innerText = "";
        }
        else {
            divemail.innerText = "*Invalid E-mail";
        }
    }


    if (username === "") {
        divUname.innerText = "*UserName is Required";
    }
    else {
        divUname.innerText = "";
    }


    if (phone === "") {
        divphn.innerText = "*Phone number is Required";
    }
    else {
        const result = isValidMobile(phone);
        if (result === false) {
            divphn.innerText = "*Invalid Mobile number";
        }
        else {
            divphn.innerText = "";
        }
    }


    if (birth === "") {
        divdob.innerText = "*Please enter your D.O.B";
    }
    else {
        const result = isValidDob(birth);
        if (result === true) {
            divdob.innerText = "";
        }
        else {
            divdob.innerText = "*Enter a Valid D.O.B";
        }
    }


    if (CR === "") {
        divcr.innerText = "*Please select your Country";
    }
    else {
        divcr.innerText = "";
    }


    if (pW1 === "") {
        divpassword1.innerText = "*Please enter your Password";
    }
    else {
        console.log(pW1)
        const result = validatePassword(pW1);
        console.log(result)
        if (result === true) {
            divpassword1.innerText = "";
        }
        else {
            divpassword1.innerText = "*Password must have more than 8 characters with atleast 1 Uppercase, 1 Lowercase, a Number and a Special character.";
        }
    }

    if (pW2 === pW1) {
        divpassword2.innerHTML = "";
    }
    else {
        divpassword2.innerText = "*Password incorrect. Re-enter your password";
    }



    if (Cbox.checked === true) {
        divcheckbox.innerHTML = "";
    }
    else {
        divcheckbox.innerText = "*Please click the checkbox";
    }


});


const isValidMobile = (phone) => {
    const re =
        /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    return re.test(String(phone).toLowerCase());
};


const isValidEmail = (mail) => {
    const re =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(mail).toLowerCase());
};

function validatePassword(pw1) {

    return /[A-Z]/       .test(pw1) &&
           /[a-z]/       .test(pw1) &&
           /[0-9]/       .test(pw1) &&
           /[^A-Za-z0-9]/.test(pw1) &&
           pw1.length > 8;

}

const isValidDob = (birth) => {
    const re =
        /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
    return re.test(String(birth).toLowerCase());
};
